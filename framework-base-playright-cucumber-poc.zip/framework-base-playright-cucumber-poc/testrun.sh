#!/bin/bash

# If tag and QA_TAG variables exists, QA_TAG value is overwritten by tag value.
if [ ! -z "${tag+x}" ] && [ ! -z "${QA_TAG+x}" ]
then
    export QA_TAG="${tag}"
# If tag variable exists and QA_TAG does not, QA_TAG is equal to tag
elif [ ! -z "${tag+x}" ] && [ -z "${QA_TAG+x}" ]
then
    export QA_TAG="${tag}"
# If QA_TAG variable exists and tag does not, tag is equal to QA_TAG
elif [ -z "${tag+x}" ] && [ ! -z "${QA_TAG+x}" ]
then
    export tag="${QA_TAG}"
fi

# QA_TAG is a mandatory variable, if not exists or has no value, abort execution.
if [ -z "${QA_TAG+x}" ]
then
    echo -e "${RED}[ERROR]${NOCOLOR} QA_TAG variable not defined. Aborting execution"
    exit 1

    if [ "${#QA_TAG}" -eq 0 ]
    then
        echo -e "${RED}[ERROR]${NOCOLOR} QA_TAG variable is declared but is empty. Aborting execution"
        exit 1
    fi
fi

echo -e "${CYAN}[INFO]${NOCOLOR} QA_TAG: ${QA_TAG}"

# If xraytestplankey and QA_XRAY_TESTPLAN_KEY variables exists, QA_XRAY_TESTPLAN_KEY value is overwritten by xraytestplankey value.
if [ ! -z "${xraytestplankey+x}" ] && [ ! -z "${QA_XRAY_TESTPLAN_KEY+x}" ]
then
    export QA_XRAY_TESTPLAN_KEY="${xraytestplankey}"
# If xraytestplankey variable exists and QA_XRAY_TESTPLAN_KEY does not, QA_XRAY_TESTPLAN_KEY is equal to xraytestplankey
elif [ ! -z "${xraytestplankey+x}" ] && [ -z "${QA_XRAY_TESTPLAN_KEY+x}" ]
then
    export QA_XRAY_TESTPLAN_KEY="${xraytestplankey}"
# If QA_XRAY_TESTPLAN_KEY variable exists and xraytestplankey does not, xraytestplankey is equal to QA_XRAY_TESTPLAN_KEY
elif [ -z "${xraytestplankey+x}" ] && [ ! -z "${QA_XRAY_TESTPLAN_KEY+x}" ]
then
    export xraytestplankey="${QA_XRAY_TESTPLAN_KEY}"
fi

# QA_XRAY_TESTPLAN_KEY is a mandatory variable, if not exists or has no value, abort execution.
if [ -z "${QA_XRAY_TESTPLAN_KEY+x}" ]
then
    echo -e "${RED}[ERROR]${NOCOLOR} QA_XRAY_TESTPLAN_KEY variable not defined. Aborting execution"
    exit 1

    if [ "${#QA_XRAY_TESTPLAN_KEY}" -eq 0 ]
    then
        echo -e "${RED}[ERROR]${NOCOLOR} QA_XRAY_TESTPLAN_KEY variable is declared but is empty. Aborting execution"
        exit 1
    fi
fi

echo -e "${CYAN}[INFO]${NOCOLOR} QA_XRAY_TESTPLAN_KEY: ${QA_XRAY_TESTPLAN_KEY}"

CHECKTESTPLANEXISTS=$(curl -s -X GET -H "Content-Type: application/json" -u "${QA_JIRA_USERNAME}:${QA_JIRA_PASSWORD}" "${QA_JIRA_URL}/search?jql=project=${QA_JIRA_PROJECT_KEY}+and+type=\"Test+Plan\"+and+key=${QA_XRAY_TESTPLAN_KEY}&fields=key&maxResults=1" | jq -r '.issues[].key')

if [ ${#CHECKTESTPLANEXISTS} -ne 0 ]
then
    echo -e "${GREEN}[SUCCESS]${NOCOLOR} QA_XRAY_TESTPLAN_KEY: ${QA_XRAY_TESTPLAN_KEY} found."
else
    echo -e "${RED}[ERROR]${NOCOLOR} QA_XRAY_TESTPLAN_KEY: ${QA_XRAY_TESTPLAN_KEY} not found. Aborting execution."
    exit 1
fi

# Define variables for Allure report
PUBLISHDATE=$(date +"%Y%m%d_%H%M%S")
QA_S3BUCKET_ALLUREREPORT_URI="s3://accsourqa-allurereport-s3/${CI_PROJECT_NAME}/${QA_ENV}/${PUBLISHDATE}_${CI_PIPELINE_ID}"
export QA_ALLUREREPORT_URL="https://central-qa.es.tui.com:8090/${CI_PROJECT_NAME}/${QA_ENV}/${PUBLISHDATE}_${CI_PIPELINE_ID}/web/index.html"

mkdir -p artifacts/allurereportfiles/raw artifacts/allurereportfiles/web

#wget https://github.com/cucumber/json-formatter/releases/download/v19.0.0/cucumber-json-formatter-linux-amd64 -O /usr/local/bin/cucumber-json-formatter
#chmod +x /usr/local/bin/cucumber-json-formatter

INPUT_DATA_URL=$(curl -s -X GET -H "Content-Type: application/json" -u "${QA_JIRA_USERNAME}:${QA_JIRA_PASSWORD}" "${QA_JIRA_URL}/issue/${QA_DATA_KEY}?fields=attachment" | jq --arg QA_DATA_NAME "$QA_DATA_NAME" -r '.fields.attachment[] | select(.filename==$QA_DATA_NAME) |.content')
echo "INPUT_DATA_URL: ${INPUT_DATA_URL}"
curl -O --output-dir test_data "${INPUT_DATA_URL}"

cat package.json
echo "npm install" >> comm.sh
echo "USE_ALLURE=1 npx cucumber-js --tags='@${QA_TAG}'" | sed s/\ and\ /\ --tags\ /g | sed s/\ and_not\ /\ --tags\ ~/g >> comm.sh
#echo "npx cypress run --env --tags=${QA_TAG}" >> comm.sh
echo -e "${CYAN}[INFO]${NOCOLOR} Executing cypress command:"
cat comm.sh
bash comm.sh

# Generate allure report
#allure generate artifacts/allurereportfiles/raw --clean -o artifacts/allurereportfiles/web
allure generate artifacts/allurereportfiles/raw -o artifacts/allurereportfiles/web 

# Upload allure report to S3 buckets for share
aws s3 sync artifacts/allurereportfiles/ ${QA_S3BUCKET_ALLUREREPORT_URI}/ --region "${QA_AWS_REGION}" --output "${QA_AWS_OUTPUT_FORMAT}" --no-progress --only-show-errors

# Publish allure report links information (S3 and Web Url) in gitlab log and add to artifacts/qa_s3bucket_allurereport_uri file.
echo -e "${CYAN}[INFO]${NOCOLOR} Allure report URL: ${QA_ALLUREREPORT_URL}"
echo "${QA_ALLUREREPORT_URL}" >> artifacts/qa_allurereport_url
echo -e "${CYAN}[INFO]${NOCOLOR} S3 Bucket allure report URI: ${QA_S3BUCKET_ALLUREREPORT_URI}" | tee -a artifacts/qa_s3bucket_allurereport_uri

# generate cucumber results json file
cat artifacts/cucumber-report.ndjson | cucumber-json-formatter > artifacts/cucumber-results.json

# Import result to xray
jq -n \
      --arg summary "$QA_XRAY_EXECUTION_SUMMARY" \
      --arg projectKey "$QA_JIRA_PROJECT_KEY" \
      --arg env "$QA_ENV" \
      --arg desc "ALLURE REPORT: ${QA_ALLUREREPORT_URL}
                  PIPELINE: ${CI_PIPELINE_URL}" \
      '{fields:{project:{key:$projectKey}, summary:$summary, customfield_26624:[$env], description:$desc}}' > artifacts/executionInfo.json

curl -u "${QA_JIRA_USERNAME}:${QA_JIRA_PASSWORD}" -F info=@artifacts/executionInfo.json -F result=@artifacts/cucumber-results.json "${QA_XRAY_API_URL}/import/execution/cucumber/multipart" | tee artifacts/executionres.json > /dev/null

# Store test execution key in a variable and in a file into artifacts
QA_XRAY_TESTEXECUTION_KEY=$(cat artifacts/executionres.json | jq -r '.testExecIssue.key')
echo "${QA_XRAY_TESTEXECUTION_KEY}" >> artifacts/test_execution_key

# Publish xray links information in gitlab log and add to artifacts/xray_plan_url and artifacts/xray_execution_url files.
echo -e "${CYAN}[INFO]${NOCOLOR} Xray test plan URL: https://jira.tuigroup.com/browse/${QA_XRAY_TESTPLAN_KEY}" | tee -a artifacts/xray_plan_url

# Check if QA_XRAY_TESTEXECUTION_KEY is null
if [ "${QA_XRAY_TESTEXECUTION_KEY}" = "null" ]
then
    echo -e "${RED}[ERROR]${NOCOLOR} QA_XRAY_TESTEXECUTION_KEY is null. Aborting execution"
    exit 1
else
    echo -e "${CYAN}[INFO]${NOCOLOR} Xray test execution URL: https://jira.tuigroup.com/browse/${QA_XRAY_TESTEXECUTION_KEY}" | tee -a artifacts/xray_execution_url
fi

# Add test execution to test plan
curl -s -X POST -H "Content-Type: application/json" -u "${QA_JIRA_USERNAME}:${QA_JIRA_PASSWORD}" --data "{\"add\": [\"${QA_XRAY_TESTEXECUTION_KEY}\"]}" "${QA_XRAY_API_URL}/api/testplan/${QA_XRAY_TESTPLAN_KEY}/testexecution"

# Add allure report and pipeline information to test execution
#curl -s -X PUT -H "Content-Type: application/json" -u "${QA_JIRA_USERNAME}:${QA_JIRA_PASSWORD}" --data "{\"fields\":{\"description\":\"ALLURE REPORT: ${QA_ALLUREREPORT_URL} \n PIPELINE: ${CI_PIPELINE_URL}\"}}" "${QA_JIRA_URL}/issue/${QA_XRAY_TESTEXECUTION_KEY}"

# Create defects and assign too testrun.
jq -c '.[]' artifacts/bugs.json | while read bug; do
    SUMMARY=$(jq -r '.summary' <<< "$bug")
    DESCRIPTION=$(jq -r '.steps' <<< "$bug")
    TEST_KEY=$(jq -r '.test_key' <<< "$bug")
    PAYLOAD=$(jq -n \
                --arg summary "$SUMMARY" \
                --arg projectKey "$QA_JIRA_PROJECT_KEY" \
                --arg issueType Bug \
                --arg description "$DESCRIPTION" \
                '{fields:{project:{key:$projectKey}, summary:$summary, description:$description, issuetype:{name:$issueType}}}')
    echo $PAYLOAD
    BUG_KEY=$(curl -s -X POST -H "Content-Type: application/json" -u "${QA_JIRA_USERNAME}:${QA_JIRA_PASSWORD}" --data "$PAYLOAD" "${QA_JIRA_URL}/issue" | jq -r .key)
    TESTRUNID=$(curl -s -X GET -H "Content-Type: application/json" -u "${QA_JIRA_USERNAME}:${QA_JIRA_PASSWORD}" "${QA_XRAY_API_URL}/api/testrun?testExecIssueKey=${QA_XRAY_TESTEXECUTION_KEY}&testIssueKey=${TEST_KEY}" | jq -r '.id')
    echo -e "${CYAN}[INFO]${NOCOLOR} Adding defect ${BUG_KEY} to testrun ${TESTRUNID} in test execution ${QA_XRAY_TESTEXECUTION_KEY}" | tee -a artifacts/defectsaddedtotestrun
    curl -s -X POST -H "Content-Type: application/json" -u "${QA_JIRA_USERNAME}:${QA_JIRA_PASSWORD}" --data "[\"${BUG_KEY}\"]" "${QA_XRAY_API_URL}/api/testrun/${TESTRUNID}/defect" > /dev/null
done

exit 0
