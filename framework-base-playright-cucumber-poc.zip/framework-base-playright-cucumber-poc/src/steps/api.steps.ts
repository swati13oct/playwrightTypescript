import { ICustomWorld } from '../support/custom-world';
import { updateXml } from '../utils/compareImages';
import { expect } from '@playwright/test';
import { Given, Then, When } from '@cucumber/cucumber';
import fs from 'fs';

Given(
  'I generate a payload to update the addressLine as {string} and cityName as {string}',
  async function (this: ICustomWorld, addressLine: string, cityName: string) {
    await updateXml(this, 'test_data/hotelDescriptiveContent.xml', addressLine, cityName);
  },
);

When('I request the descriptiveContent service', async function (this: ICustomWorld) {
  const dataPayload = fs.readFileSync('test_data/hotelDescriptiveContent.xml', 'utf8');
  this.attach(dataPayload, 'application/xml');
  this.response = await this.server?.post('/connect-tui-masterdata', {
    headers: {
      'content-type': 'application/soap+xml;charset=utf-8',
    },
    data: dataPayload,
  });
});

Then('I verify the response', async function (this: ICustomWorld) {
  expect(this.response?.ok()).toBeTruthy();
  if (typeof this.response !== 'undefined') {
    this.attach(await this.response.body(), 'application/json');
  }
  //expect(response).toBeDefined();
});
